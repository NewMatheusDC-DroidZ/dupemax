package com.newmatheusdc.dupemax;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class DupemaxMod implements ModInitializer {
    public static final String MOD_ID = "dupemax";
    public static final String VERSION = "1.1.0";
    private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static final AtomicBoolean enabled = new AtomicBoolean(true);
    private static final AtomicInteger maxAmount = new AtomicInteger(64);
    private static final AtomicBoolean requireOp = new AtomicBoolean(false);

    private static File configFile;

    @Override
    public void onInitialize() {
        LOGGER.info("[Dupemax] Initializing Dupemax v{} by NewMatheusDC", VERSION);
        LOGGER.info("[Dupemax] Loading for Minecraft 1.21.11 with Fabric Loader");

        loadConfig();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            LOGGER.debug("[Dupemax] Registering commands...");

            dispatcher.register(Commands.literal("dupemax")
                .requires(DupemaxMod::isAdmin)
                .then(Commands.literal("enable")
                    .executes(ctx -> {
                        LOGGER.info("[Dupemax] Admin {} executed /dupemax enable", getName(ctx));
                        return toggle(ctx, true);
                    }))
                .then(Commands.literal("disable")
                    .executes(ctx -> {
                        LOGGER.info("[Dupemax] Admin {} executed /dupemax disable", getName(ctx));
                        return toggle(ctx, false);
                    }))
                .then(Commands.literal("amount")
                    .then(Commands.argument("number", IntegerArgumentType.integer(1, 64))
                        .executes(ctx -> {
                            int newAmount = IntegerArgumentType.getInteger(ctx, "number");
                            LOGGER.info("[Dupemax] Admin {} executed /dupemax amount {}", getName(ctx), newAmount);
                            return setMaxAmount(ctx, newAmount);
                        }))
                    .executes(ctx -> {
                        LOGGER.info("[Dupemax] Admin {} executed /dupemax amount (query)", getName(ctx));
                        ctx.getSource().sendSuccess(() -> Component.literal("[Dupemax] Current max dupe amount: " + maxAmount.get()), false);
                        return 1;
                    }))
                .then(Commands.literal("requireop")
                    .then(Commands.literal("true")
                        .executes(ctx -> setRequireOp(ctx, true)))
                    .then(Commands.literal("false")
                        .executes(ctx -> setRequireOp(ctx, false)))
                    .executes(ctx -> {
                        ctx.getSource().sendSuccess(() -> Component.literal("[Dupemax] requireOp is currently: " + requireOp.get()), false);
                        return 1;
                    }))
                .then(Commands.literal("viewconfig")
                    .executes(DupemaxMod::viewConfig)));

            dispatcher.register(Commands.literal("dupe")
                .requires(DupemaxMod::canUse)
                .then(Commands.argument("amount", IntegerArgumentType.integer(1, 64))
                    .executes(ctx -> {
                        int amount = IntegerArgumentType.getInteger(ctx, "amount");
                        LOGGER.info("[Dupemax] Player {} executed /dupe {}", getName(ctx), amount);
                        return dupeHand(ctx, amount);
                    }))
                .executes(ctx -> {
                    LOGGER.info("[Dupemax] Player {} executed /dupe (default)", getName(ctx));
                    return dupeHand(ctx, -1);
                }));

            dispatcher.register(Commands.literal("dupeinv")
                .requires(DupemaxMod::canUse)
                .then(Commands.argument("item", StringArgumentType.greedyString())
                    .suggests(DupemaxMod::suggestItems)
                    .executes(ctx -> {
                        String itemName = StringArgumentType.getString(ctx, "item").toLowerCase().trim();
                        LOGGER.info("[Dupemax] Player {} executed /dupeinv {}", getName(ctx), itemName);
                        return dupeInventoryByItem(ctx, itemName);
                    }))
                .executes(ctx -> {
                    LOGGER.info("[Dupemax] Player {} executed /dupeinv (all)", getName(ctx));
                    return dupeInventory(ctx);
                }));

            LOGGER.info("[Dupemax] Commands registered successfully");
        });

        LOGGER.info("[Dupemax] Dupemax v{} initialized. Max amount: {}, requireOp: {}, Status: {}",
            VERSION, maxAmount.get(), requireOp.get(), enabled.get() ? "enabled" : "disabled");
    }

    private static String getName(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer p = ctx.getSource().getPlayer();
        return p != null ? p.getName().getString() : "Console";
    }

    private static boolean isAdmin(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return false;
        boolean isOp = source.getServer().getPlayerList().isOp(player.nameAndId());
        if (!isOp) {
            LOGGER.warn("[Dupemax] Admin permission denied for: {}", player.getName().getString());
        }
        return isOp;
    }

    private static boolean canUse(CommandSourceStack source) {
        if (!enabled.get()) {
            LOGGER.warn("[Dupemax] Command blocked - mod is disabled");
            return false;
        }
        if (requireOp.get()) {
            return isAdmin(source);
        }
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            LOGGER.debug("[Dupemax] Permission check failed - source is not a player");
            return false;
        }
        return true;
    }

    private static int toggle(CommandContext<CommandSourceStack> ctx, boolean state) {
        if (enabled.get() == state) {
            String already = state ? "already enabled" : "already disabled";
            LOGGER.warn("[Dupemax] Admin {} tried to {} but mod is already {}",
                getName(ctx), state ? "enable" : "disable", already);
            ctx.getSource().sendFailure(Component.literal("[Dupemax] Mod is already " + already + "."));
            return 0;
        }
        enabled.set(state);
        saveConfig();
        String status = state ? "enabled" : "disabled";
        LOGGER.info("[Dupemax] Mod status changed to: {}", status);
        ctx.getSource().sendSuccess(() -> Component.literal("[Dupemax] Mod " + status), true);
        return 1;
    }

    private static int setMaxAmount(CommandContext<CommandSourceStack> ctx, int amount) {
        if (maxAmount.get() == amount) {
            LOGGER.warn("[Dupemax] Admin {} tried to set amount to {} but it is already {}",
                getName(ctx), amount, amount);
            ctx.getSource().sendFailure(Component.literal("[Dupemax] Max amount is already " + amount + "."));
            return 0;
        }
        int oldAmount = maxAmount.get();
        maxAmount.set(amount);
        saveConfig();
        LOGGER.info("[Dupemax] Max dupe amount changed from {} to {}", oldAmount, amount);
        ctx.getSource().sendSuccess(() -> Component.literal("[Dupemax] Max dupe amount set to: " + amount), true);
        return 1;
    }

    private static int setRequireOp(CommandContext<CommandSourceStack> ctx, boolean state) {
        if (requireOp.get() == state) {
            String already = state ? "already true" : "already false";
            LOGGER.warn("[Dupemax] Admin {} tried to set requireOp to {} but it is already {}",
                getName(ctx), state, already);
            ctx.getSource().sendFailure(Component.literal("[Dupemax] requireOp is already " + state + "."));
            return 0;
        }
        requireOp.set(state);
        saveConfig();
        LOGGER.info("[Dupemax] requireOp changed to: {}", state);
        ctx.getSource().sendSuccess(() -> Component.literal("[Dupemax] requireOp set to: " + state + ". " +
            (state ? "Only operators can use /dupe and /dupeinv now." : "All players can use /dupe and /dupeinv now.")), true);
        return 1;
    }

    private static int viewConfig(CommandContext<CommandSourceStack> ctx) {
        LOGGER.info("[Dupemax] Admin {} viewed config", getName(ctx));
        ctx.getSource().sendSuccess(() -> Component.literal(
            "=== Dupemax Config ===\n" +
            "Version: " + VERSION + "\n" +
            "Status: " + (enabled.get() ? "enabled" : "disabled") + "\n" +
            "Max Amount: " + maxAmount.get() + "\n" +
            "Require OP: " + requireOp.get() + "\n" +
            "Config File: config/dupemax.json\n" +
            "======================"
        ), false);
        return 1;
    }

    private static int dupeHand(CommandContext<CommandSourceStack> ctx, int amount) {
        ServerPlayer player = ctx.getSource().getPlayer();
        if (player == null) {
            LOGGER.error("[Dupemax] /dupe failed - command source is not a player");
            ctx.getSource().sendFailure(Component.literal("[Dupemax] Only players can use this command."));
            return 0;
        }

        String playerName = player.getName().getString();
        ItemStack held = player.getMainHandItem();

        if (held.isEmpty()) {
            LOGGER.warn("[Dupemax] /dupe failed for {} - no item in main hand", playerName);
            ctx.getSource().sendFailure(Component.literal("[Dupemax] Hold an item in your main hand first."));
            return 0;
        }

        int toGive;
        if (amount == -1) {
            toGive = Math.min(held.getCount(), maxAmount.get());
        } else {
            toGive = Math.min(amount, maxAmount.get());
        }

        ItemStack copy = held.copy();
        copy.setCount(toGive);

        if (!player.getInventory().add(copy)) {
            LOGGER.warn("[Dupemax] /dupe failed for {} - inventory full, item not dropped", playerName);
            ctx.getSource().sendFailure(Component.literal("[Dupemax] No space left in inventory. Item was not duplicated (no drops)."));
            return 0;
        }

        String itemName = getItemName(held);
        LOGGER.info("[Dupemax] Successfully duped {}x {} for player {}", toGive, itemName, playerName);
        ctx.getSource().sendSuccess(() -> Component.literal("[Dupemax] Duped " + toGive + "x " + itemName), false);
        return 1;
    }

    private static int dupeInventory(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = ctx.getSource().getPlayer();
        if (player == null) {
            LOGGER.error("[Dupemax] /dupeinv failed - command source is not a player");
            ctx.getSource().sendFailure(Component.literal("[Dupemax] Only players can use this command."));
            return 0;
        }

        String playerName = player.getName().getString();
        LOGGER.info("[Dupemax] Starting full inventory duplication for player {}", playerName);

        var inv = player.getInventory();
        int added = 0;
        int skipped = 0;
        int emptySlots = 0;

        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) {
                emptySlots++;
                continue;
            }

            ItemStack copy = stack.copy();
            if (!inv.add(copy)) {
                skipped++;
                LOGGER.debug("[Dupemax] Skipped duplicating slot {} for {} - no space", i, playerName);
            } else {
                added++;
                LOGGER.debug("[Dupemax] Duplicated slot {} for {}", i, playerName);
            }
        }

        LOGGER.info("[Dupemax] Full inventory duplication complete for {} - {} stacks added, {} skipped, {} empty slots",
            playerName, added, skipped, emptySlots);
        int finalAdded = added;
        int finalSkipped = skipped;
        ctx.getSource().sendSuccess(() -> Component.literal(
            "[Dupemax] Duplicated " + finalAdded + " stacks. Skipped " + finalSkipped + " (no space)."), false);
        return 1;
    }

    private static int dupeInventoryByItem(CommandContext<CommandSourceStack> ctx, String itemName) {
        ServerPlayer player = ctx.getSource().getPlayer();
        if (player == null) {
            LOGGER.error("[Dupemax] /dupeinv <item> failed - command source is not a player");
            ctx.getSource().sendFailure(Component.literal("[Dupemax] Only players can use this command."));
            return 0;
        }

        String playerName = player.getName().getString();
        LOGGER.info("[Dupemax] Starting targeted duplication for '{}' for player {}", itemName, playerName);

        var inv = player.getInventory();
        int foundStacks = 0;
        int added = 0;
        int skipped = 0;
        int totalItems = 0;

        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) continue;

            String stackName = getItemName(stack).toLowerCase();
            String itemId = stack.getItem().toString().toLowerCase();

            if (stackName.contains(itemName) || itemId.contains(itemName)) {
                foundStacks++;
                totalItems += stack.getCount();
                ItemStack copy = stack.copy();
                if (!inv.add(copy)) {
                    skipped++;
                    LOGGER.debug("[Dupemax] Skipped duplicating '{}' in slot {} for {} - no space", itemName, i, playerName);
                } else {
                    added++;
                    LOGGER.debug("[Dupemax] Duplicated '{}' in slot {} for {}", itemName, i, playerName);
                }
            }
        }

        if (foundStacks == 0) {
            LOGGER.warn("[Dupemax] /dupeinv failed for {} - no items matching '{}' found", playerName, itemName);
            ctx.getSource().sendFailure(Component.literal("[Dupemax] No items matching '" + itemName + "' found in your inventory."));
            return 0;
        }

        LOGGER.info("[Dupemax] Targeted duplication complete for {} - found {} stacks ({} items), {} added, {} skipped",
            playerName, foundStacks, totalItems, added, skipped);
        int finalAdded = added;
        int finalFound = foundStacks;
        int finalTotal = totalItems;
        int finalSkipped = skipped;
        ctx.getSource().sendSuccess(() -> Component.literal(
            "[Dupemax] Found " + finalFound + " stacks of '" + itemName + "' (" + finalTotal + " items). " +
            "Duplicated " + finalAdded + " stacks. Skipped " + finalSkipped + " (no space)."), false);
        return 1;
    }

    private static String getItemName(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "Air";
        String name = stack.getHoverName().getString();
        if (name == null || name.isEmpty() || name.equals("Air")) {
            name = stack.getItem().toString();
        }
        return name;
    }

    private static CompletableFuture<Suggestions> suggestItems(CommandContext<CommandSourceStack> ctx, SuggestionsBuilder builder) {
        ServerPlayer player = ctx.getSource().getPlayer();
        if (player != null) {
            Set<String> suggested = new HashSet<>();
            var inv = player.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack stack = inv.getItem(i);
                if (!stack.isEmpty()) {
                    String name = getItemName(stack);
                    if (!suggested.contains(name) && name.toLowerCase().startsWith(builder.getRemaining().toLowerCase())) {
                        builder.suggest(name);
                        suggested.add(name);
                    }
                }
            }
        }
        return builder.buildFuture();
    }

    private static void loadConfig() {
        configFile = new File(FabricLoader.getInstance().getConfigDir().toFile(), "dupemax.json");
        if (!configFile.exists()) {
            LOGGER.info("[Dupemax] Config file not found, creating default config...");
            saveConfig();
            return;
        }

        try (FileReader reader = new FileReader(configFile)) {
            ConfigData data = GSON.fromJson(reader, ConfigData.class);
            if (data != null) {
                maxAmount.set(data.maxAmount);
                requireOp.set(data.requireOp);
                enabled.set(data.enabled);
                LOGGER.info("[Dupemax] Config loaded. maxAmount: {}, requireOp: {}, enabled: {}",
                    data.maxAmount, data.requireOp, data.enabled);
            }
        } catch (IOException e) {
            LOGGER.error("[Dupemax] Failed to load config, using defaults: {}", e.getMessage());
        }
    }

    private static void saveConfig() {
        if (configFile == null) {
            configFile = new File(FabricLoader.getInstance().getConfigDir().toFile(), "dupemax.json");
        }
        ConfigData data = new ConfigData();
        data.maxAmount = maxAmount.get();
        data.requireOp = requireOp.get();
        data.enabled = enabled.get();

        try (FileWriter writer = new FileWriter(configFile)) {
            GSON.toJson(data, writer);
            LOGGER.debug("[Dupemax] Config saved successfully");
        } catch (IOException e) {
            LOGGER.error("[Dupemax] Failed to save config: {}", e.getMessage());
        }
    }

    private static class ConfigData {
        int maxAmount = 64;
        boolean requireOp = false;
        boolean enabled = true;
    }
}
